// =====================================================================================
//  Squad - nucleo (Electron, a mesma base do Discord). 13/11/2026.
//  - Abre a pagina do Squad numa janela propria, servida por um servidorzinho em 127.0.0.1
//    (porta fixa: o navegador guarda conta e ajustes por endereco, e o endereco inclui a porta).
//  - Seletor de tela NOSSO (Telas e Janelas com miniatura): sem a janelinha do Edge/Chrome.
//  - Som do PC igual ao Discord: o ajudante somdopc.exe pega "todo o som do PC menos o do Squad".
//  - Atualizacao sozinha: so avisa quando a versao no GitHub e MAIOR que a que esta rodando E o
//    arquivo novo ja foi baixado e conferido (SHA-256). Nada de comparar texto: zero aviso falso.
// =====================================================================================
const { app, BrowserWindow, session, desktopCapturer, ipcMain, shell, Menu, dialog, screen } = require("electron");
const http = require("http");
const fs = require("fs");
const os = require("os");
const path = require("path");
const crypto = require("crypto");
const { spawn, execFile } = require("child_process");

const S = global.SQUAD || { versao: "0", dir: __dirname, embutido: __dirname, pastaVersoes: path.join(app.getPath("userData"), "versoes"),
  maior: () => false, programa: path.dirname(process.execPath) };
const DIR = S.dir;

// ---------------- ajustes do programa (15/11): as duas chaves de video do Discord ----------------
// "Aceleracao de hardware H.264" e "OpenH264". Valem ao abrir (o Chromium so le isso na partida).
// Igual ao Discord: desligar o OpenH264 desliga junto a aceleracao pela placa de video.
const ARQ_AJUSTES = path.join(app.getPath("userData"), "ajustes-programa.json");
const AJUSTES = { aceleracaoH264: true, openH264: true };
try { const lido = JSON.parse(fs.readFileSync(ARQ_AJUSTES, "utf8")); for (const k of Object.keys(AJUSTES)) if (typeof lido[k] === "boolean") AJUSTES[k] = lido[k]; } catch (e) {}
const EM_USO = Object.assign({}, AJUSTES);        // o que esta valendo nesta abertura
// 15/11: transmitir "janela" pegava um RECORTE DA TELA (o que estivesse na frente aparecia por cima do filme -
// visto no quadro recebido). Com a captura de janela do Windows (WGC) vem so a janela escolhida, igual ao Discord.
app.commandLine.appendSwitch("enable-features", "AllowWgcWindowCapturer");
if (!AJUSTES.aceleracaoH264 || !AJUSTES.openH264) {
  app.commandLine.appendSwitch("disable-accelerated-video-encode");
  app.commandLine.appendSwitch("disable-accelerated-video-decode");
}
const PORTAS = [47841, 47842, 47843, 47844, 47845];
const WEB = path.join(DIR, "web");
const AJUDANTE = path.join(DIR, "somdopc.exe");
const REPO = "crocodilo-afk/super-party";
const INSTALADOR = "https://github.com/" + REPO + "/raw/master/squad/InstalarSquad.exe";
const TIPOS = { ".html": "text/html; charset=utf-8", ".js": "application/javascript; charset=utf-8", ".css": "text/css",
  ".png": "image/png", ".svg": "image/svg+xml", ".ico": "image/x-icon", ".json": "application/json" };

// ---------------- desinstalar (o "Desinstalar" do Windows chama Squad.exe --desinstalar) ----------------
if (process.argv.includes("--desinstalar")) { desinstalar(); return; }
function desinstalar() {
  app.whenReady().then(async () => {
    if (!app.requestSingleInstanceLock()) {
      dialog.showMessageBoxSync({ type: "warning", title: "Squad", message: "O Squad está aberto.\nFeche a janela dele e clique em Desinstalar de novo." });
      return app.exit(0);
    }
    const r = dialog.showMessageBoxSync({ type: "question", title: "Squad", buttons: ["Desinstalar", "Cancelar"], defaultId: 1, cancelId: 1,
      message: "Desinstalar o Squad deste computador?", detail: "Sua conta daqui (nome, foto, ajustes) também é apagada. Se quiser guardar, abra o Squad antes e use \"Salvar minha conta\"." });
    if (r !== 0) return app.exit(0);
    const tirar = p => { try { fs.rmSync(p, { force: true }); } catch (e) {} };
    tirar(path.join(app.getPath("desktop"), "Squad.lnk"));
    tirar(path.join(app.getPath("appData"), "Microsoft", "Windows", "Start Menu", "Programs", "Squad.lnk"));
    execFile("reg.exe", ["delete", "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Squad", "/f"], { windowsHide: true });
    const dados = app.getPath("userData"), prog = S.programa;
    // a pasta do programa so some depois que este processo fechar
    const apagar = fs.existsSync(path.join(prog, "Squad.exe")) ? 'rmdir /s /q "' + prog + '" & ' : "";
    spawn("cmd.exe", ["/c", "timeout /t 3 /nobreak >nul & " + apagar + 'rmdir /s /q "' + dados + '"'], { detached: true, windowsHide: true, stdio: "ignore" }).unref();
    dialog.showMessageBoxSync({ type: "info", title: "Squad", message: "Pronto, o Squad foi removido." });
    app.exit(0);
  });
}

if (!app.requestSingleInstanceLock()) { app.quit(); return; }
let janela = null, fonteEscolhida = null, avisoPendente = null, ultimaCaptura = {};

// 16/11: jogo/filme em TELA CHEIA nao deixa capturar so a janela (o Windows entrega preto ou nada).
// O ajudante diz se a janela cobre o monitor inteiro e qual e; ai a captura vai pro monitor, igual ao Discord.
function estadoDaJanela(idFonte) {
  return new Promise(ok => {
    const hwnd = String(idFonte).split(":")[1];
    if (!/^\d+$/.test(hwnd || "") || !fs.existsSync(AJUDANTE)) return ok(null);
    execFile(AJUDANTE, ["janela", hwnd], { windowsHide: true, timeout: 3000 }, (e, saida) => {
      const m = /^cheia (-?\d+) (-?\d+) (-?\d+) (-?\d+)/.exec(String(saida || "").trim());
      ok(m ? { x: +m[1], y: +m[2], w: +m[3] - +m[1], h: +m[4] - +m[2] } : null);
    });
  });
}
function telaDoRetangulo(lista, r) {
  const telas = lista.filter(x => x.id.startsWith("screen"));
  if (telas.length === 1) return telas[0];
  for (const d of screen.getAllDisplays()) {
    let b = d.bounds;
    try { b = screen.dipToScreenRect(null, d.bounds); } catch (e) {}
    const perto = (a, c) => Math.abs(a - c) <= 2;
    if (perto(b.x, r.x) && perto(b.y, r.y) && perto(b.width, r.w) && perto(b.height, r.h))
      return telas.find(x => x.display_id === String(d.id)) || null;
  }
  return null;
}

// ---------------- servidorzinho local ----------------
function servir(req, res) {
  const url = new URL(req.url, "http://127.0.0.1");
  const p = decodeURIComponent(url.pathname);
  if (p === "/versao") { res.writeHead(200, { "Content-Type": "text/plain" }); return res.end(S.versao); }
  if (p === "/somdopc/teste") {
    if (!fs.existsSync(AJUDANTE)) { res.writeHead(404); return res.end("sem ajudante"); }
    const t = spawn(AJUDANTE, ["teste", String(process.pid)], { windowsHide: true });
    let saida = ""; t.stdout.on("data", d => saida += d);
    const fim = setTimeout(() => { try { t.kill(); } catch (e) {} }, 6000);
    t.on("close", () => { clearTimeout(fim); res.writeHead(200, { "Content-Type": "text/plain" }); res.end(saida.trim() || "erro"); });
    return;
  }
  if (p === "/somdopc") {
    const t = spawn(AJUDANTE, [String(process.pid)], { windowsHide: true });
    res.writeHead(200, { "Content-Type": "application/octet-stream", "Cache-Control": "no-store" });
    t.stdout.pipe(res);
    const parar = () => { try { t.kill(); } catch (e) {} };
    req.on("close", parar); res.on("close", parar);
    t.on("close", () => { try { res.end(); } catch (e) {} });
    return;
  }
  const arq = path.normalize(path.join(WEB, p === "/" ? "index.html" : p));
  if (!arq.startsWith(WEB) || !fs.existsSync(arq) || fs.statSync(arq).isDirectory()) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { "Content-Type": TIPOS[path.extname(arq).toLowerCase()] || "application/octet-stream", "Cache-Control": "no-store" });
  fs.createReadStream(arq).pipe(res);
}
function ligarServidor() {
  return new Promise((ok, erro) => {
    const tentar = i => {
      if (i >= PORTAS.length) return erro(new Error("nenhuma porta livre"));
      const s = http.createServer(servir);
      s.once("error", () => tentar(i + 1));
      s.listen(PORTAS[i], "127.0.0.1", () => ok(PORTAS[i]));
    };
    tentar(0);
  });
}

// ---------------- seletor de tela nosso ----------------
ipcMain.handle("squad:fontes", async () => {
  const lista = await desktopCapturer.getSources({ types: ["screen", "window"], thumbnailSize: { width: 400, height: 225 }, fetchWindowIcons: true });
  const minha = janela ? janela.getMediaSourceId() : "";
  return lista.filter(f => f.id !== minha && f.name !== "Squad").map(f => ({
    id: f.id, nome: f.name, tipo: f.id.startsWith("screen") ? "tela" : "janela",
    miniatura: f.thumbnail.isEmpty() ? "" : f.thumbnail.toDataURL(),
    icone: f.appIcon && !f.appIcon.isEmpty() ? f.appIcon.toDataURL() : ""
  }));
});
ipcMain.handle("squad:escolher", (e, id) => { fonteEscolhida = typeof id === "string" ? id : null; return true; });
ipcMain.handle("squad:ajustes", () => ({ salvo: AJUSTES, emUso: EM_USO }));
ipcMain.handle("squad:ajustar", (e, chave, valor) => {
  if (!Object.prototype.hasOwnProperty.call(AJUSTES, chave) || typeof valor !== "boolean") return false;
  AJUSTES[chave] = valor;
  try { fs.writeFileSync(ARQ_AJUSTES, JSON.stringify(AJUSTES)); return true; } catch (x) { return false; }
});
ipcMain.handle("squad:versao", () => S.versao);
ipcMain.handle("squad:ultimaCaptura", () => ultimaCaptura);
ipcMain.handle("squad:reiniciar", () => { app.relaunch(); app.exit(0); });
ipcMain.handle("squad:instalador", () => shell.openExternal(INSTALADOR));
ipcMain.handle("squad:procurar", () => procurarAtualizacao(true));

// ---------------- ATUALIZACAO ----------------
function avisar(info) { avisoPendente = info; if (janela && !janela.isDestroyed()) janela.webContents.send("squad:atualizacao", info); }
async function baixar(url) {
  const r = await fetch(url, { headers: { "User-Agent": "Squad" }, redirect: "follow" });
  if (!r.ok) throw new Error("baixar " + r.status);
  return Buffer.from(await r.arrayBuffer());
}
function extrair(zip, destino) {
  return new Promise((ok, erro) => {
    execFile(path.join(process.env.WINDIR || "C:\\Windows", "System32", "tar.exe"), ["-xf", zip, "-C", destino], { windowsHide: true },
      e => e ? erro(e) : ok());
  });
}
// Tudo mora no repositorio, na pasta squad/: o manifesto squad.json diz a versao, o arquivo do
// nucleo e a impressao digital (SHA-256) dele. O manifesto vem pela API do GitHub (sem cache velho).
const RAW = "https://raw.githubusercontent.com/" + REPO + "/master/";
let procurando = false;
async function procurarAtualizacao(manual) {
  if (procurando) return "ocupado";
  procurando = true;
  try {
    const r = await fetch("https://api.github.com/repos/" + REPO + "/contents/squad/squad.json?ref=master",
      { headers: { "User-Agent": "Squad", "Accept": "application/vnd.github.raw" } });
    if (!r.ok) return "sem resposta";
    const manifesto = await r.json();
    const versao = String(manifesto.versao || "");
    if (!/^\d+(\.\d+)*$/.test(versao)) return "sem versao";
    if (!S.maior(versao, S.versao)) return "em dia";                      // igual ou mais velha: NAO avisa
    if (manifesto.electron !== process.versions.electron) {                 // mudou a base: so reinstalando
      avisar({ tipo: "instalador", versao, notas: manifesto.notas || "" }); return "precisa instalador";
    }
    const dir = path.join(S.pastaVersoes, versao);
    if (!fs.existsSync(path.join(dir, "pronto"))) {
      if (!/^squad\/nucleo\/[\w.-]+\.zip$/.test(String(manifesto.nucleo || ""))) return "manifesto errado";
      const dados = await baixar(RAW + manifesto.nucleo);
      const hash = crypto.createHash("sha256").update(dados).digest("hex");
      if (hash !== String(manifesto.nucleo_sha256).toLowerCase()) return "arquivo nao confere";   // corrompido ou trocado: ignora
      fs.mkdirSync(S.pastaVersoes, { recursive: true });
      const tmpZip = path.join(os.tmpdir(), "squad-" + versao + ".zip"), tmpDir = dir + ".baixando";
      fs.writeFileSync(tmpZip, dados);
      fs.rmSync(tmpDir, { recursive: true, force: true }); fs.mkdirSync(tmpDir, { recursive: true });
      await extrair(tmpZip, tmpDir);
      fs.rmSync(tmpZip, { force: true });
      if (!fs.existsSync(path.join(tmpDir, "nucleo.js"))) { fs.rmSync(tmpDir, { recursive: true, force: true }); return "pacote incompleto"; }
      fs.rmSync(dir, { recursive: true, force: true }); fs.renameSync(tmpDir, dir);
      fs.writeFileSync(path.join(dir, "pronto"), versao);                    // o ultimo passo: so agora a partida aceita
    }
    avisar({ tipo: "pronta", versao, notas: manifesto.notas || "" });
    return "pronta";
  } catch (e) { return "erro: " + e.message; }
  finally { procurando = false; }
}
// apaga versoes velhas (fica so a que esta rodando e as mais novas)
function limparVersoes() {
  try {
    for (const nome of fs.readdirSync(S.pastaVersoes)) {
      if (nome.endsWith(".baixando") || S.maior(S.versao, nome)) fs.rmSync(path.join(S.pastaVersoes, nome), { recursive: true, force: true });
    }
  } catch (e) {}
}

app.whenReady().then(async () => {
  Menu.setApplicationMenu(null);
  const porta = await ligarServidor();
  const origem = "http://127.0.0.1:" + porta;
  const s = session.defaultSession;
  s.setPermissionRequestHandler((wc, perm, ok) => ok(["media", "display-capture", "clipboard-sanitized-write", "clipboard-read", "notifications", "fullscreen"].includes(perm)));
  s.setPermissionCheckHandler(() => true);
  s.setDisplayMediaRequestHandler(async (pedido, responder) => {
    try {
      const lista = await desktopCapturer.getSources({ types: ["screen", "window"] });
      let f = lista.find(x => x.id === fonteEscolhida) || lista.find(x => x.id.startsWith("screen"));
      fonteEscolhida = null;
      ultimaCaptura = { telaCheia: false, som: pedido.audioRequested ? "geral" : "programa" };
      if (f && f.id.startsWith("window:")) {
        const r = await estadoDaJanela(f.id);
        const t = r && telaDoRetangulo(lista, r);
        if (t) { f = t; ultimaCaptura.telaCheia = true; }
      }
      if (!f) return responder({});
      // 16/11: a pagina so pede som aqui quando o ajudante (captura por programa) nao funciona neste Windows.
      // Plano B: o som geral do Windows (loopback), sem a pessoa marcar nada.
      responder(pedido.audioRequested ? { video: f, audio: "loopback" } : { video: f });
    } catch (e) { responder({}); }
  });

  janela = new BrowserWindow({
    width: 1440, height: 900, minWidth: 980, minHeight: 640, backgroundColor: "#08080a", title: "Squad",
    icon: path.join(S.embutido, "..", "squad.ico"), autoHideMenuBar: true, show: false,
    webPreferences: { preload: path.join(DIR, "preload.js"), contextIsolation: true, sandbox: true, backgroundThrottling: false }
  });
  janela.once("ready-to-show", () => janela.show());
  janela.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/i.test(url)) shell.openExternal(url); return { action: "deny" }; });
  janela.webContents.on("will-navigate", (e, url) => { if (!url.startsWith(origem)) { e.preventDefault(); if (/^https?:/i.test(url)) shell.openExternal(url); } });
  janela.webContents.on("did-finish-load", () => { if (avisoPendente) janela.webContents.send("squad:atualizacao", avisoPendente); });
  janela.loadURL(origem + "/");
  janela.on("closed", () => { janela = null; });

  limparVersoes();
  setTimeout(() => procurarAtualizacao(false), 8000);
  setInterval(() => procurarAtualizacao(false), 30 * 60 * 1000);
});
app.on("second-instance", () => { if (janela) { if (janela.isMinimized()) janela.restore(); janela.focus(); } });
app.on("window-all-closed", () => app.quit());
