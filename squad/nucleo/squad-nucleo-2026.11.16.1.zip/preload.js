// Ponte entre a pagina e o programa: so isto, nada mais.
const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("squad", {
  fontes: () => ipcRenderer.invoke("squad:fontes"),            // telas e janelas, com miniatura
  escolher: id => ipcRenderer.invoke("squad:escolher", id),    // a proxima transmissao usa esta
  ajustes: () => ipcRenderer.invoke("squad:ajustes"),          // chaves de video do programa (H.264)
  ajustar: (chave, valor) => ipcRenderer.invoke("squad:ajustar", chave, valor),
  versao: () => ipcRenderer.invoke("squad:versao"),
  ultimaCaptura: () => ipcRenderer.invoke("squad:ultimaCaptura"),   // tela cheia virou monitor? som geral?
  reiniciar: () => ipcRenderer.invoke("squad:reiniciar"),      // abre de novo ja na versao nova
  instalador: () => ipcRenderer.invoke("squad:instalador"),
  procurar: () => ipcRenderer.invoke("squad:procurar"),
  onAtualizacao: cb => ipcRenderer.on("squad:atualizacao", (e, info) => cb(info))
});
