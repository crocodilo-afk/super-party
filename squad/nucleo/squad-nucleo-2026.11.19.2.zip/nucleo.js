// =====================================================================================
//  Squad - nucleo (Electron, a mesma base do Discord). 13/11/2026.
//  - Abre a pagina do Squad numa janela propria, servida por um servidorzinho em 127.0.0.1
//    (porta fixa: o navegador guarda conta e ajustes por endereco, e o endereco inclui a porta).
//  - Seletor de tela NOSSO (Telas e Janelas com miniatura): sem a janelinha do Edge/Chrome.
//  - Som do PC igual ao Discord: o ajudante somdopc.exe pega "todo o som do PC menos o do Squad".
//  - Atualizacao sozinha: so avisa quando a versao no GitHub e MAIOR que a que esta rodando E o
//    arquivo novo ja foi baixado e conferido (SHA-256). Nada de comparar texto: zero aviso falso.
// =====================================================================================
const { app, BrowserWindow, session, desktopCapturer, ipcMain, shell, Menu, dialog, screen, safeStorage } = require("electron");
const http = require("http");
const fs = require("fs");
const os = require("os");
const path = require("path");
const crypto = require("crypto");
const { spawn, execFile } = require("child_process");

const S = global.SQUAD || { versao: "0", dir: __dirname, embutido: __dirname, pastaVersoes: path.join(app.getPath("userData"), "versoes"),
  maior: () => false, programa: path.dirname(process.execPath) };
const DIR = S.dir;

// ---------------- ajustes do programa (15/11): as duas chaves de video do Discord ----------------
// "Aceleracao de hardware H.264" e "OpenH264". Valem ao abrir (o Chromium so le isso na partida).
// Igual ao Discord: desligar o OpenH264 desliga junto a aceleracao pela placa de video.
const ARQ_AJUSTES = path.join(app.getPath("userData"), "ajustes-programa.json");
const AJUSTES = { aceleracaoH264: true, openH264: true };
try { const lido = JSON.parse(fs.readFileSync(ARQ_AJUSTES, "utf8")); for (const k of Object.keys(AJUSTES)) if (typeof lido[k] === "boolean") AJUSTES[k] = lido[k]; } catch (e) {}
const EM_USO = Object.assign({}, AJUSTES);        // o que esta valendo nesta abertura
// 15/11: transmitir "janela" pegava um RECORTE DA TELA (o que estivesse na frente aparecia por cima do filme -
// visto no quadro recebido). Com a captura de janela do Windows (WGC) vem so a janela escolhida, igual ao Discord.
app.commandLine.appendSwitch("enable-features", "AllowWgcWindowCapturer");
if (!AJUSTES.aceleracaoH264 || !AJUSTES.openH264) {
  app.commandLine.appendSwitch("disable-accelerated-video-encode");
  app.commandLine.appendSwitch("disable-accelerated-video-decode");
}
const PORTAS = [47841, 47842, 47843, 47844, 47845];
const WEB = path.join(DIR, "web");
const AJUDANTE = path.join(DIR, "somdopc.exe");
const REPO = "crocodilo-afk/super-party";
const INSTALADOR = "https://github.com/" + REPO + "/raw/master/squad/InstalarSquad.exe";
const TIPOS = { ".html": "text/html; charset=utf-8", ".js": "application/javascript; charset=utf-8", ".css": "text/css",
  ".png": "image/png", ".svg": "image/svg+xml", ".ico": "image/x-icon", ".json": "application/json" };

// ---------------- desinstalar (o "Desinstalar" do Windows chama Squad.exe --desinstalar) ----------------
if (process.argv.includes("--desinstalar")) { desinstalar(); return; }
function desinstalar() {
  app.whenReady().then(async () => {
    if (!app.requestSingleInstanceLock()) {
      dialog.showMessageBoxSync({ type: "warning", title: "YapSquad", message: "O YapSquad está aberto.\nFeche a janela dele e clique em Desinstalar de novo." });
      return app.exit(0);
    }
    const r = dialog.showMessageBoxSync({ type: "question", title: "YapSquad", buttons: ["Desinstalar", "Cancelar"], defaultId: 1, cancelId: 1,
      message: "Desinstalar o YapSquad deste computador?", detail: "Sua conta daqui (nome, foto, ajustes) também é apagada. Se quiser guardar, abra o YapSquad antes e use \"Salvar minha conta\"." });
    if (r !== 0) return app.exit(0);
    const tirar = p => { try { fs.rmSync(p, { force: true }); } catch (e) {} };
    tirar(path.join(app.getPath("desktop"), "Squad.lnk"));
    tirar(path.join(app.getPath("appData"), "Microsoft", "Windows", "Start Menu", "Programs", "Squad.lnk"));
    execFile("reg.exe", ["delete", "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Squad", "/f"], { windowsHide: true });
    const dados = app.getPath("userData"), prog = S.programa;
    // a pasta do programa so some depois que este processo fechar
    const apagar = fs.existsSync(path.join(prog, "Squad.exe")) ? 'rmdir /s /q "' + prog + '" & ' : "";
    spawn("cmd.exe", ["/c", "timeout /t 3 /nobreak >nul & " + apagar + 'rmdir /s /q "' + dados + '"'], { detached: true, windowsHide: true, stdio: "ignore" }).unref();
    dialog.showMessageBoxSync({ type: "info", title: "YapSquad", message: "Pronto, o YapSquad foi removido." });
    app.exit(0);
  });
}

if (!app.requestSingleInstanceLock()) { app.quit(); return; }
let janela = null, fonteEscolhida = null, avisoPendente = null, ultimaCaptura = {};

// 16/11: jogo/filme em TELA CHEIA nao deixa capturar so a janela (o Windows entrega preto ou nada).
// O ajudante diz se a janela cobre o monitor inteiro e qual e; ai a captura vai pro monitor, igual ao Discord.
function estadoDaJanela(idFonte) {
  return new Promise(ok => {
    const hwnd = String(idFonte).split(":")[1];
    if (!/^\d+$/.test(hwnd || "") || !fs.existsSync(AJUDANTE)) return ok(null);
    execFile(AJUDANTE, ["janela", hwnd], { windowsHide: true, timeout: 3000 }, (e, saida) => {
      const m = /^cheia (-?\d+) (-?\d+) (-?\d+) (-?\d+)/.exec(String(saida || "").trim());
      ok(m ? { x: +m[1], y: +m[2], w: +m[3] - +m[1], h: +m[4] - +m[2] } : null);
    });
  });
}
function telaDoRetangulo(lista, r) {
  const telas = lista.filter(x => x.id.startsWith("screen"));
  if (telas.length === 1) return telas[0];
  for (const d of screen.getAllDisplays()) {
    let b = d.bounds;
    try { b = screen.dipToScreenRect(null, d.bounds); } catch (e) {}
    const perto = (a, c) => Math.abs(a - c) <= 2;
    if (perto(b.x, r.x) && perto(b.y, r.y) && perto(b.width, r.w) && perto(b.height, r.h))
      return telas.find(x => x.display_id === String(d.id)) || null;
  }
  return null;
}

// ---------------- servidorzinho local ----------------
function servir(req, res) {
  const url = new URL(req.url, "http://127.0.0.1");
  const p = decodeURIComponent(url.pathname);
  if (p === "/versao") { res.writeHead(200, { "Content-Type": "text/plain" }); return res.end(S.versao); }
  // 16/11: volta do "Entrar com Google/Discord". O navegador da pessoa cai aqui com ?code=;
  // o codigo vai pra pagina, que troca pela sessao (PKCE: sem o segredo da pagina ele nao vale nada).
  if (p === "/entrou") {
    const codigo = url.searchParams.get("code") || "";
    const erro = (url.searchParams.get("error_description") || url.searchParams.get("error") || "").slice(0, 200);
    const valeu = /^[\w-]{6,300}$/.test(codigo);
    if (janela && (valeu || erro)) {
      janela.webContents.send("squad:entrou", valeu ? codigo : "", erro);
      if (janela.isMinimized()) janela.restore();
      janela.show(); janela.focus();
    }
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
    return res.end('<!doctype html><meta charset="utf-8"><title>YapSquad</title><body style="margin:0;height:100vh;display:flex;align-items:center;justify-content:center;background:#08080a;color:#f5f1ea;font:600 20px Segoe UI,sans-serif;text-align:center">' +
      (valeu ? "<div>Pronto! Pode voltar pro <b style=\"color:#ff7a1a\">YapSquad</b>.<br><small style=\"color:#a39d94\">Já pode fechar esta aba.</small></div>"
             : "<div>Não deu pra entrar.<br><small style=\"color:#a39d94\">Volte pro YapSquad e tente de novo.</small></div>") +
      "<script>setTimeout(function(){window.close()},1500)</script></body>");
  }
  if (p === "/somdopc/teste") {
    if (!fs.existsSync(AJUDANTE)) { res.writeHead(404); return res.end("sem ajudante"); }
    const t = spawn(AJUDANTE, ["teste", String(process.pid)], { windowsHide: true });
    let saida = ""; t.stdout.on("data", d => saida += d);
    const fim = setTimeout(() => { try { t.kill(); } catch (e) {} }, 6000);
    t.on("close", () => { clearTimeout(fim); res.writeHead(200, { "Content-Type": "text/plain" }); res.end(saida.trim() || "erro"); });
    return;
  }
  if (p === "/somdopc") {
    const t = spawn(AJUDANTE, [String(process.pid)], { windowsHide: true });
    res.writeHead(200, { "Content-Type": "application/octet-stream", "Cache-Control": "no-store" });
    t.stdout.pipe(res);
    const parar = () => { try { t.kill(); } catch (e) {} };
    req.on("close", parar); res.on("close", parar);
    t.on("close", () => { try { res.end(); } catch (e) {} });
    return;
  }
  const arq = path.normalize(path.join(WEB, p === "/" ? "index.html" : p));
  if (!arq.startsWith(WEB) || !fs.existsSync(arq) || fs.statSync(arq).isDirectory()) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { "Content-Type": TIPOS[path.extname(arq).toLowerCase()] || "application/octet-stream", "Cache-Control": "no-store" });
  fs.createReadStream(arq).pipe(res);
}
function ligarServidor() {
  return new Promise((ok, erro) => {
    const tentar = i => {
      if (i >= PORTAS.length) return erro(new Error("nenhuma porta livre"));
      const s = http.createServer(servir);
      s.once("error", () => tentar(i + 1));
      s.listen(PORTAS[i], "127.0.0.1", () => ok(PORTAS[i]));
    };
    tentar(0);
  });
}

// ---------------- seletor de tela nosso ----------------
ipcMain.handle("squad:fontes", async () => {
  const lista = await desktopCapturer.getSources({ types: ["screen", "window"], thumbnailSize: { width: 400, height: 225 }, fetchWindowIcons: true });
  const minha = janela ? janela.getMediaSourceId() : "";
  return lista.filter(f => f.id !== minha && f.name !== "Squad" && f.name !== "YapSquad").map(f => ({
    id: f.id, nome: f.name, tipo: f.id.startsWith("screen") ? "tela" : "janela",
    miniatura: f.thumbnail.isEmpty() ? "" : f.thumbnail.toDataURL(),
    icone: f.appIcon && !f.appIcon.isEmpty() ? f.appIcon.toDataURL() : ""
  }));
});
ipcMain.handle("squad:escolher", (e, id) => { fonteEscolhida = typeof id === "string" ? id : null; return true; });
ipcMain.handle("squad:ajustes", () => ({ salvo: AJUSTES, emUso: EM_USO }));
ipcMain.handle("squad:ajustar", (e, chave, valor) => {
  if (!Object.prototype.hasOwnProperty.call(AJUSTES, chave) || typeof valor !== "boolean") return false;
  AJUSTES[chave] = valor;
  try { fs.writeFileSync(ARQ_AJUSTES, JSON.stringify(AJUSTES)); return true; } catch (x) { return false; }
});
ipcMain.handle("squad:versao", () => S.versao);
ipcMain.handle("squad:janela", (e, acao) => {   // duplo clique na barra = maximizar/voltar, igual ao Windows
  if (!janela) return false;
  if (acao === "maximizar") { if (janela.isMaximized()) janela.unmaximize(); else janela.maximize(); }
  return janela.isMaximized();
});
ipcMain.handle("squad:ultimaCaptura", () => ultimaCaptura);
ipcMain.handle("squad:reiniciar", () => { app.relaunch(); app.exit(0); });
ipcMain.handle("squad:instalador", () => shell.openExternal(INSTALADOR));
ipcMain.handle("squad:procurar", () => procurarComCalma(true));
// 19/11 ("entrei com o e-mail e nao salvou"): o login ficava so no localStorage, que o Electron grava com atraso;
// fechou o programa logo depois = a chave nova de renovar se perdia e o Supabase derrubava a conta.
// Agora vai tambem num arquivo cifrado pelo Windows (DPAPI, so este usuario do PC abre), gravado na hora.
const ARQ_CONTA = path.join(app.getPath("userData"), "conta.dat");
ipcMain.on("squad:lerConta", e => {
  try { e.returnValue = safeStorage.isEncryptionAvailable() ? safeStorage.decryptString(fs.readFileSync(ARQ_CONTA)) : ""; }
  catch (err) { e.returnValue = ""; }
});
ipcMain.handle("squad:guardarConta", (e, txt) => {
  try {
    if (!txt) { fs.rmSync(ARQ_CONTA, { force: true }); return true; }
    if (!safeStorage.isEncryptionAvailable()) return false;
    const tmp = ARQ_CONTA + ".tmp";
    fs.writeFileSync(tmp, safeStorage.encryptString(String(txt).slice(0, 20000)));
    fs.renameSync(tmp, ARQ_CONTA);
    try { session.defaultSession.flushStorageData(); } catch (err) {}
    return true;
  } catch (err) { return false; }
});
app.on("before-quit", () => { try { session.defaultSession.flushStorageData(); } catch (e) {} });

// ---------------- ATUALIZACAO ----------------
function avisar(info) { avisoPendente = info; if (janela && !janela.isDestroyed()) janela.webContents.send("squad:atualizacao", info); }
// 17/11 ("ta dando muito erro"): cada tentativa fica anotada em %APPDATA%\Squad\atualizacao.log (pra medir, nao chutar)
const ARQ_LOG = path.join(app.getPath("userData"), "atualizacao.log");
function anotar(texto) {
  try {
    const linha = new Date().toISOString() + " v" + S.versao + " " + texto + "\n";
    let velho = ""; try { velho = fs.readFileSync(ARQ_LOG, "utf8"); } catch (e) {}
    const linhas = (velho + linha).split("\n").slice(-300).join("\n");
    fs.writeFileSync(ARQ_LOG, linhas);
  } catch (e) {}
}
async function baixar(url, extra) {
  const r = await fetch(url, { headers: Object.assign({ "User-Agent": "Squad", "Cache-Control": "no-cache" }, extra || {}),
    redirect: "follow", signal: AbortSignal.timeout(120000) });
  if (!r.ok) throw new Error("baixar " + r.status + " " + url.replace(/\?.*/, ""));
  return Buffer.from(await r.arrayBuffer());
}
// dois caminhos pro mesmo arquivo: o raw (rapido) e a API do GitHub (sem cache velho). Se um falhar, tenta o outro.
// (17/11, medido depois de publicar: o raw segura o squad.json velho por ate 5 min, mesmo com ?t=. Por isso o
// manifesto vem PRIMEIRO pela API, que e sempre fresca; o pacote, que tem nome novo a cada versao, vem pelo raw.)
async function baixarDoRepo(caminho, apiPrimeiro) {
  const erros = [];
  const rotas = [[RAW + caminho + "?t=" + Date.now(), null],
    ["https://api.github.com/repos/" + REPO + "/contents/" + caminho + "?ref=master", { "Accept": "application/vnd.github.raw" }]];
  if (apiPrimeiro) rotas.reverse();
  for (const [url, extra] of rotas) {
    try { return await baixar(url, extra); } catch (e) { erros.push(e.message); }
  }
  throw new Error(erros.join(" | "));
}
function extrair(zip, destino) {
  return new Promise((ok, erro) => {
    execFile(path.join(process.env.WINDIR || "C:\\Windows", "System32", "tar.exe"), ["-xf", zip, "-C", destino], { windowsHide: true },
      e => e ? erro(e) : ok());
  });
}
// Tudo mora no repositorio, na pasta squad/: o manifesto squad.json diz a versao, o arquivo do
// nucleo e a impressao digital (SHA-256) dele. O manifesto vem pela API do GitHub (sem cache velho).
const RAW = "https://raw.githubusercontent.com/" + REPO + "/master/";
let procurando = false;
async function procurarAtualizacao(manual) {
  if (procurando) return "ocupado";
  procurando = true;
  try {
    const manifesto = JSON.parse((await baixarDoRepo("squad/squad.json", true)).toString("utf8").replace(/^\uFEFF/, ""));
    const versao = String(manifesto.versao || "");
    if (!/^\d+(\.\d+)*$/.test(versao)) return "sem versao";
    if (!S.maior(versao, S.versao)) return "em dia";                      // igual ou mais velha: NAO avisa
    if (manifesto.electron !== process.versions.electron) {                 // mudou a base: so reinstalando
      avisar({ tipo: "instalador", versao, notas: manifesto.notas || "" }); return "precisa instalador";
    }
    const dir = path.join(S.pastaVersoes, versao);
    if (!fs.existsSync(path.join(dir, "pronto"))) {
      if (!/^squad\/nucleo\/[\w.-]+\.zip$/.test(String(manifesto.nucleo || ""))) return "manifesto errado";
      let dados = await baixarDoRepo(manifesto.nucleo);
      let hash = crypto.createHash("sha256").update(dados).digest("hex");
      if (hash !== String(manifesto.nucleo_sha256).toLowerCase()) {      // copia velha no cache do raw: pega pela API
        anotar("hash diferente pelo raw, tentando pela API");
        dados = await baixar("https://api.github.com/repos/" + REPO + "/contents/" + manifesto.nucleo + "?ref=master", { "Accept": "application/vnd.github.raw" });
        hash = crypto.createHash("sha256").update(dados).digest("hex");
        if (hash !== String(manifesto.nucleo_sha256).toLowerCase()) return "arquivo nao confere";   // corrompido ou trocado: ignora
      }
      fs.mkdirSync(S.pastaVersoes, { recursive: true });
      const tmpZip = path.join(os.tmpdir(), "squad-" + versao + ".zip"), tmpDir = dir + ".baixando";
      fs.writeFileSync(tmpZip, dados);
      fs.rmSync(tmpDir, { recursive: true, force: true }); fs.mkdirSync(tmpDir, { recursive: true });
      await extrair(tmpZip, tmpDir);
      fs.rmSync(tmpZip, { force: true });
      if (!fs.existsSync(path.join(tmpDir, "nucleo.js"))) { fs.rmSync(tmpDir, { recursive: true, force: true }); return "pacote incompleto"; }
      fs.rmSync(dir, { recursive: true, force: true }); fs.renameSync(tmpDir, dir);
      fs.writeFileSync(path.join(dir, "pronto"), versao);                    // o ultimo passo: so agora a partida aceita
    }
    avisar({ tipo: "pronta", versao, notas: manifesto.notas || "" });
    return "pronta";
  } catch (e) { return "erro: " + e.message; }
  finally { procurando = false; }
}
// procura, anota o resultado e, se deu erro de internet, tenta de novo em 2, 5 e 10 minutos (antes esperava 30)
let tentativasErro = 0;
async function procurarComCalma(manual) {
  const r = await procurarAtualizacao(manual);
  anotar((manual ? "[manual] " : "") + r);
  if (/^erro|sem resposta|pacote incompleto|arquivo nao confere/.test(r) && tentativasErro < 3) {
    const espera = [2, 5, 10][tentativasErro++] * 60 * 1000;
    setTimeout(() => procurarComCalma(false), espera);
  } else if (!/^erro/.test(r)) tentativasErro = 0;
  return r;
}
// apaga versoes velhas (fica so a que esta rodando e as mais novas)
function limparVersoes() {
  try {
    for (const nome of fs.readdirSync(S.pastaVersoes)) {
      if (nome.endsWith(".baixando") || S.maior(S.versao, nome)) fs.rmSync(path.join(S.pastaVersoes, nome), { recursive: true, force: true });
    }
  } catch (e) {}
}

app.whenReady().then(async () => {
  Menu.setApplicationMenu(null);
  const porta = await ligarServidor();
  const origem = "http://127.0.0.1:" + porta;
  const s = session.defaultSession;
  s.setPermissionRequestHandler((wc, perm, ok) => ok(["media", "display-capture", "clipboard-sanitized-write", "clipboard-read", "notifications", "fullscreen"].includes(perm)));
  s.setPermissionCheckHandler(() => true);
  s.setDisplayMediaRequestHandler(async (pedido, responder) => {
    try {
      const lista = await desktopCapturer.getSources({ types: ["screen", "window"] });
      let f = lista.find(x => x.id === fonteEscolhida) || lista.find(x => x.id.startsWith("screen"));
      fonteEscolhida = null;
      ultimaCaptura = { telaCheia: false, som: pedido.audioRequested ? "geral" : "programa" };
      if (f && f.id.startsWith("window:")) {
        const r = await estadoDaJanela(f.id);
        const t = r && telaDoRetangulo(lista, r);
        if (t) { f = t; ultimaCaptura.telaCheia = true; }
      }
      if (!f) return responder({});
      // 16/11: a pagina so pede som aqui quando o ajudante (captura por programa) nao funciona neste Windows.
      // Plano B: o som geral do Windows (loopback), sem a pessoa marcar nada.
      responder(pedido.audioRequested ? { video: f, audio: "loopback" } : { video: f });
    } catch (e) { responder({}); }
  });

  janela = new BrowserWindow({
    width: 1440, height: 900, minWidth: 980, minHeight: 640, backgroundColor: "#08080a", title: "YapSquad",
    icon: path.join(S.embutido, "..", "squad.ico"), autoHideMenuBar: true, show: false,
    // 17/11 ("a janela igual ao Discord"): sem a moldura branca do Windows. A pagina desenha a barra de cima
    // (arrasta a janela por ela) e o Windows desenha so os 3 botoes, na nossa cor - continua encaixando nos cantos.
    titleBarStyle: "hidden", titleBarOverlay: { color: "#08080a", symbolColor: "#a39d94", height: 34 },
    webPreferences: { preload: path.join(DIR, "preload.js"), contextIsolation: true, sandbox: true, backgroundThrottling: false }
  });
  janela.once("ready-to-show", () => janela.show());
  janela.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/i.test(url)) shell.openExternal(url); return { action: "deny" }; });
  janela.webContents.on("will-navigate", (e, url) => { if (!url.startsWith(origem)) { e.preventDefault(); if (/^https?:/i.test(url)) shell.openExternal(url); } });
  janela.webContents.on("did-finish-load", () => { if (avisoPendente) janela.webContents.send("squad:atualizacao", avisoPendente); });
  janela.loadURL(origem + "/");
  janela.on("closed", () => { janela = null; });

  limparVersoes();
  setTimeout(() => procurarComCalma(false), 8000);
  setInterval(() => procurarComCalma(false), 30 * 60 * 1000);
});
app.on("second-instance", () => { if (janela) { if (janela.isMinimized()) janela.restore(); janela.focus(); } });
app.on("window-all-closed", () => app.quit());
